function About() {
  return (
    <div>
      <h1>About</h1>
      <p>This is a student portal for managing courses.</p>
    </div>
  );
}

export default About;