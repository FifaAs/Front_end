function Home() {
  return (
    <div>
      <h1>Welcome to Student Portal</h1>
    </div>
  );
}

export default Home;